<?php
_deprecated_file( __FILE__, '4.2', 'Tribe__Events__JSON_LD__Event' );

class Tribe__Events__Google_Data_Markup__Event extends Tribe__Events__Google_Data_Markup {}
